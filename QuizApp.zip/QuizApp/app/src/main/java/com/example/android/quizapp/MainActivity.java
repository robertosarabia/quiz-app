/**
 * IMPORTANT: Make sure you are using the correct package name.
 * This example uses the package name:
 * package com.example.android.justjava
 * If you get an error when copying this code into Android studio, update it to match teh package name found
 * in the project's AndroidManifest.xml file.
 **/

package com.example.android.quizapp;


import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import com.example.android.quizapp.R;

import java.text.NumberFormat;

/**
 * This app is a simple math quiz that demonstrates interactivity.
 */
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    /**
     * This method is called when the submit button is clicked.
     * It calculates and prints a toast of the score after receiving inputs for each question.
     */
    public void getResults(View view) {
        // Get the user's response to Question 1
        EditText question1Answer1 = (EditText) findViewById(R.id.question1_answer1);
        String question1A1 = question1Answer1.getText().toString();
        // Checks for answer 'zero' and increments score
        int question1Score;
        if (question1A1.equalsIgnoreCase("zero")) {
            question1Score = 1;
        } else {
            question1Score = 0;
        }

        // Get the user's check box responses for Question 2
        CheckBox question2Answer1 = (CheckBox) findViewById(R.id.checkbox_main_answer1);
        boolean question2A1 = question2Answer1.isChecked();
        CheckBox question2Answer2 = (CheckBox) findViewById(R.id.checkbox_main_answer2);
        boolean question2A2 = question2Answer2.isChecked();
        CheckBox question2Answer3 = (CheckBox) findViewById(R.id.checkbox_main_answer3);
        boolean question2A3 = question2Answer3.isChecked();
        CheckBox question2Answer4 = (CheckBox) findViewById(R.id.checkbox_main_answer4);
        boolean question2A4 = question2Answer4.isChecked();
        // Checks for only question2Answer2 checkbox to be checked and increments score
        int question2Score;
        if (question2A1 == true && question2A2 == true && question2A3 == true && question2A4 == false) {
            question2Score = 1;
        } else {
            question2Score = 0;
        }

        // Get the user's radio button responses for Question 3
        RadioButton question3A2 = (RadioButton) this.findViewById(R.id.button_main_question3_choice2);
        Boolean answer3 = question3A2.isChecked();

        // Checks for only button_main_question3_choice2 to be selected and increments score
        int question3Score;
        if (answer3) {
            question3Score = 1;
        } else {
            question3Score = 0;
        }

        // Get the user's radio button responses for Question 4
        RadioButton question4A1 = (RadioButton) this.findViewById(R.id.button_main_question4_choice1);
        Boolean answer4 = question4A1.isChecked();

        // Checks for only button_main_question4_choice1 to be selected and increments score
        int question4Score;
        if (answer4) {
            question4Score = 1;
        } else {
            question4Score = 0;
        }

        // Get the user's radio button responses for Question 5
        RadioButton question5A1 = (RadioButton) this.findViewById(R.id.button_main_question5_choice1);
        Boolean answer5 = question5A1.isChecked();

        // Checks for only button_main_question4_choice1 to be selected and increments score
        int question5Score;
        if (answer5) {
            question5Score = 1;
        } else {
            question5Score = 0;
        }

        // Calculates user's final quiz score as the sum of points gained from each question
        int score;
        score = question1Score + question2Score + question3Score + question4Score + question5Score;

        // Shows score as a toast
        String scoreMessage = "Final score: " + score + " out of 5!";
        Toast.makeText(this, scoreMessage, Toast.LENGTH_SHORT).show();
    }
}